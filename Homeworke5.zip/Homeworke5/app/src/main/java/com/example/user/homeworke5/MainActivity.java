package com.example.user.homeworke5;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText et1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void show(View view) {
        et1 = findViewById(R.id.et1);
        String firstname = et1.getText().toString().trim();
        if (firstname.isEmpty()) {

            et1.setError("Empty");
            et1.requestFocus();
        } else {
            Intent i = new Intent(this, NextData.class);
            i.putExtra("k1", firstname);
            startActivityForResult(i, 1212);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        Bundle b=data.getExtras();
        String fname=b.getString("k1");
        String lastname=b.getString("k2");
        TextView tv2=findViewById(R.id.tv2);
        tv2.setText(fname+""+lastname);
        et1.setText(" ");
    }
}
