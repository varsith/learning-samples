package com.example.user.homeworke5;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
public class NextData extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next_data);

        Intent i = getIntent();
        Bundle b = i.getExtras();
        String s1 = b.getString("k1");
        TextView tv = findViewById(R.id.tv2);
        tv.setText(s1);
    }
    public void show1(View view) {

        Intent i = getIntent();
        Bundle b = i.getExtras();
        String s1 = b.getString("k1");
        EditText et = findViewById(R.id.et2);
        String lastname = et.getText().toString().trim();
        if (lastname.isEmpty()) {
            et.setError("Empty");
            et.requestFocus();
        } else {
            Intent i1 = new Intent();
            i1.putExtra("k1", s1);
            i1.putExtra("k2", lastname);

            setResult(RESULT_OK, i1);
            finish();


        }
    }
}
